#!/bin/bash

make clean && make depend && make
